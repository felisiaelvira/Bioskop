<?php

// include './connection.php';
$servername = "localhost";
$username = "root";
$password = "";
$database = "bioskop";
// $port  = "3306";

// Create connection
// $conn = new mysqli($servername, $username, $password, $database, $port);
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

//Membuat fungsi Login
function login($data)
{
	global $conn;

	$username = $data['username']; //deklarasi variabel utk mengambil data usernama
	$password = $data['password'];


	$queryPass = "SELECT password FROM users WHERE username = '$username' && password = '$password';";
	$results = mysqli_query($conn, $queryPass);

	$row = mysqli_fetch_assoc($results);
	if (mysqli_num_rows($results) > 0) {
		return 1;
	} else {
		return 0;
	}
}


function getFilmId($id) {
  global $conn;

  $query = "SELECT * FROM films WHERE id_film = $id";
  $results = mysqli_query($conn, $query);

  $rows = [];

  while ($row = mysqli_fetch_assoc($results)) {
    $rows[] = $row;
  }

  return $rows;
}

function getKodeFlim($kode) {
  global $conn;

  $query = "SELECT * FROM films WHERE kode_film = '$kode'";
  $results = mysqli_query($conn, $query);

  $rows = [];

  while ($row = mysqli_fetch_assoc($results)) {
    $rows[] = $row;
  }

  return $rows;

}

function getAllFilms()
{
  global $conn;
  
  $query = "SELECT * FROM films;";
  $results = mysqli_query($conn, $query);
  
  $rows = [];

  while ($row = mysqli_fetch_assoc($results)) {
    $rows[] = $row;
  }

  return $rows;
}

function register($data)
{
  global $conn;
  $nama = $data["nama"];
  $username = $data["username"];
  $pass = $data["password"];
  $email = $data["email"];
  $telepon = $data["telepon"];


  $checkEmail = "SELECT * FROM users WHERE email = '$email'";
  $checkTrue = mysqli_query($conn, $checkEmail);


  // return mysqli_num_rows($checkTrue);
  if(mysqli_num_rows($checkTrue) < 1) {
    $query = "INSERT INTO `users` (`nama`, `no_telepon`, `email`, `username`, `password`) 
    VALUES ('$nama', '$telepon', '$email', '$username', '$pass');";
    mysqli_query($conn, $query);
  
    return 1;
  } else {
    return -2;
  }
}

function editFilm($data, $id) {
  global $conn;

  $kode = $data['kode'];
  $judul = $data['judul'];
  $jam = $data['jam'];
  $sinopsis = $data['sinopsis'];
  $harga = $data['harga'];
  $status = $data['status'];
  $posterDefault = $data['posterDefault'];

  if($_FILES['gambar']['error'] === 4) {
    $poster = $posterDefault;
  } else {
    $poster = upload();
  }

  $query = "UPDATE `films` 
            SET `kode_film` = '$kode', 
                `judul` = '$judul', 
                `jam_tayang` = '$jam', 
                `sinopsis` = '$sinopsis', 
                `harga` = $harga, 
                `status` = '$status', 
                `poster` = '$poster' 
            WHERE `films`.`id_film` = $id;";

mysqli_query($conn, $query);

return mysqli_affected_rows($conn);
}

function tambahFilm($data)
{
  global $conn;
  $kode = $data['kode'];
  $judul = $data['judul'];
  $jam = $data['jam'];
  $sinopsis = $data['sinopsis'];
  $harga = $data['harga'];
  $status = $data['status'];
  $poster = upload();


  $query = "INSERT INTO `films` (`id_film`, `kode_film`, `judul`, `jam_tayang`, `sinopsis`, `harga`, `status`, `poster`) 
  VALUES (NULL, '$kode', '$judul', '$jam', '$sinopsis', $harga, '$status', '$poster');";
  mysqli_query($conn, $query);

  return mysqli_affected_rows($conn);

}

function upload() {
  $namaPoster = $_FILES["gambar"]["name"];
  $tmp = $_FILES["gambar"]["tmp_name"];
  // $err = $_FILES["gambar"]["error"];
  $valid = ['jpg', 'jpeg', 'png'];
  $extension = explode('.', $namaPoster);
  $extension = strtolower(end($valid));

  $newFile = uniqid();
  $newFile .= '.';
  $newFile .= $extension;


  move_uploaded_file($tmp, '../resources/imgFilm/'.$newFile);
  return $newFile;
}

function buyTiket($post, $get) {
  global $conn;

  $film = $get['id_film'];
  $studio = $post['seat'];

  $query = "INSERT INTO `tikets` (`id_tiket`, `id_film`, `id_studio`) VALUES (NULL, $film, $studio);";
  mysqli_query($conn, $query);

  return mysqli_affected_rows($conn);
}

function getTiket() {
  global $conn;
  
  $query = "SELECT * FROM tikets;";
  $results = mysqli_query($conn, $query);
  
  $rows = [];

  while ($row = mysqli_fetch_assoc($results)) {
    $rows[] = $row;
  }

  return $rows;
}

function addPemesanan($kode, $user, $harga) {
  global $conn;

  $indexTiket = sizeof(getTiket());
  $tkt = getTiket()[$indexTiket-1];
  $inpTkt = $tkt['id_tiket'];


  $query = "INSERT INTO `informasi_pemesanan` (`kode_pemesanan`, `id_user`, `id_tiket`, `total_harga`) 
  VALUES ($kode, $user, $inpTkt, $harga);";
  mysqli_query($conn, $query);

  return mysqli_affected_rows($conn);
}

function getPemesanan($id) {
  global $conn;
  
  // $query = "SELECT * FROM informasi_pemesanan WHERE kode_pemesanan = $id;";
  $query = "SELECT i.kode_pemesanan, i.id_tiket, i.id_user, f.kode_film, f.judul, i.total_harga
  FROM informasi_pemesanan as i
  JOIN tikets as t ON i.id_tiket = t.id_tiket
  JOIN films as f ON t.id_film = f.id_film
  WHERE kode_pemesanan = $id;";
  $results = mysqli_query($conn, $query);
  
  $rows = [];

  while ($row = mysqli_fetch_assoc($results)) {
    $rows[] = $row;
  }

  return $rows;
}

function deleteFilm($id) {
  global $conn;

  $query = "DELETE FROM films WHERE id_film = $id";
  mysqli_query($conn, $query);

  return mysqli_affected_rows($conn);

}