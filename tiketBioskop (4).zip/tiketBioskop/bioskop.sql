-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Des 2022 pada 07.57
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bioskop`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `films`
--

CREATE TABLE `films` (
  `id_film` int(11) NOT NULL,
  `kode_film` varchar(50) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `jam_tayang` time NOT NULL,
  `sinopsis` text NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `poster` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `films`
--

INSERT INTO `films` (`id_film`, `kode_film`, `judul`, `jam_tayang`, `sinopsis`, `harga`, `status`, `poster`) VALUES
(41, 'P001', 'QORIN', '15:40:00', 'Zahra (Zulfa Maharani) adalah siswi teladan di sekolah putri yang ingin segera lulus. Keinginannya segera lulus mendapat hambatan dari Ujay (Omar Daniel), Kepala Sekolah pengganti yang punya rencana jahat untuk para siswi.\r\n\r\nSuatu hari, sekolah kedatangan siswi baru bergaya rebel bernama Yolanda (Aghniny Haque). Ujay meminta Zahra mendampingi Yolanda dalam masa orientasi. Zahra juga diminta Ujay memimpin teman-temannya melakukan ritual Qorin.\r\n\r\nRitual Qorin adalah ritual memanggil kembaran ghaib setiap manusia. Usai ritual, asrama tempat Zahra dan Yolanda tinggal bersama siswi lain mulai diteror oleh sosok-sosok ghaib. Semua siswi yang ikut ritual Qorin juga dihantui makhluk yang menyerupai diri mereka.\r\n\r\nKemunculan jin Qorin mulai menghantui dan membuat para siswi melakukan dosa yang tak terbayangkan. Nyawa mereka pun terancam diambil alih oleh jin Qorin itu. Zahra, Yolanda, dan teman-temannya, bersama dua pengasuh asrama, Umi Hana (Dea Annisa) dan Umi Yana (Putri Ayudya) harus memberanikan diri bangkit melawan jin Qorin.\r\n\r\nSanggupkah mereka melawan sisi kelam dan jahat dalam diri mereka sendiri?', 35000, 'playing', '6391e5113d98d.png'),
(42, 'P002', 'SRI ASIH', '16:00:00', 'Alana tidak mengerti mengapa dia selalu dikuasai oleh kemarahan. Tapi dia selalu berusaha untuk melawannya. Dia lahir saat letusan gunung berapi yang memisahkan dia dan orang tuanya. Dia kemudian diadopsi oleh seorang wanita kaya yang berusaha membantunya menjalani kehidupan normal. Tapi saat dewasa, Alana menemukan kebenaran tentang asalnya. Dia bukan manusia biasa. Dia bisa menjadi kebaikan untuk kehidupan. Atau menjadi kehancuran bila ia tidak dapat mengendalikan amarahnya.', 35000, 'playing', '6391e4cb31df2.png'),
(43, 'F003', 'AADC', '15:00:00', 'Ada Apa dengan Cinta bertemakan cinta di masa-masa SMA dan menampilkan tokoh utama Cinta (Dian Sastrowardoyo) sebagai seorang gadis yang cantik, pintar, dan periang. Ia merupakan langganan juara lomba puisi di sekolahnya yang rutin diadakan tiap tahun. Cinta memiliki sebuah geng yang sangat kompak bersama empat temannya yang lain, yaitu Alya (Ladya Cherill), Carmen (Adinia Wirasti), Maura (Titi Kamal), dan Milly (Sissy Priscillia). Cerita berawal dari Alya yang tubuhnya memar karena kerap dipukuli oleh sang ayah yang kerap cek-cok dengan ibunya.', 35000, 'soon', '638ee597284fe.png'),
(44, 'F004', 'Dear Nathan', '15:00:00', 'Salma (Amanda Rawles) merupakan seorang murid pindahan di SMA Garuda. Suatu pagi ia terlambat datang ke upacara bendera dan seorang murid bernama Nathan (Jefri Nichol), yang dikenal sebagai murid berandal yang hobi tawuran, menyelamatkannya dari hukuman. Salma, yang bertekad untuk selektif memilih teman, berusaha menjauhi Nathan, tetapi Nathan justru membuat heboh satu sekolah dengan terang-terangan mengejar cinta Salma. Berbagai cara dilakukan Salma untuk menghindar, tetapi semakin ia menjauh, semakin ia dihadapkan pada kesempatan demi kesempatan untuk memahami masa lalu Nathan dan perlahan jatuh cinta. Saat Nathan mulai membuka diri dan mau berubah demi Salma, kekasih masa lalu Nathan, Seli (Denira Wiraguna), datang untuk meminta cintanya kembali.', 50000, 'soon', '638ee8ba44f2a.png'),
(45, 'F005', 'SHERINA', '18:00:00', 'Sherina, seorang gadis cilik yang cerdik dan energetik, tiap kali ia bermain dan berlari-larian dengan sahabat-sahabatnya tersayang. Anak periang ini tinggal di Jakarta bersama ayah dan ibunya, Pak dan Bu Darmawan. Sayang sekali, kehidupan dan teman-teman yang telah lama ia kenal harus ditinggalkannya ketika ayahnya yang agronom lulusan IPB diterima bekerja oleh Pak Ardiwilaga, seorang pemilik perkebunan di Lembang. Dengan sedih dan berat hati, Sherina mengikuti kedua orangtuanya pindah ke Bandung.\r\n\r\nDi lingkungannya yang baru, Sherina dapat cepat menyesuaikan diri dan memperoleh teman-teman baru. Namun ia pun menjadi sasaran kejahilan “bandit kelas,” seorang anak lelaki bernama Sadam, yang bersama dua anteknya, Dudung dan Icang, kerap menggoda dan mempermainkan anak-anak lain, khususnya anak-anak yang lebih lemah. Sherina tidak tinggal diam, ia menyemangati teman-temannya untuk berani menantang dan melawan kesewenang-wenangan Sadam dan konco-konconya.', 40000, 'soon', '638ee8f560c23.png'),
(46, 'F006', 'HANGOUT', '17:00:00', 'Seorang pria misterius bernama Toni Sacalu, dengan inisial Tonni P. Sacalu mengundang 9 publik figur untuk ‘Hangout’ di villa di sebuah pulau terpencil,\r\nHangout ini bertujuan untuk membicarakan sebuah proyek dengan sejumlah uang besar. Mereka pun berangkat memenuhi undangan tersebut.\r\nSetibanya di sana, masalah muncul sejak malam pertama ketika Mathias Muchus mati diracun di hadapan mereka. Kendala berikutnya, mereka tidak bisa segera kembali karena perahu penjemput mereka, akan tiba lima hari kemudian. Mereka pun terjebak dalam pulau tersebut.\r\nMereka berusaha untuk bertahan hidup, tapi satu persatu malah mati. Ketika tinggal berempat, salah seorang dari mereka berhasil menemukan siapa pembunuhnya. Sayang belum sempat memberitahu siapa pembunuhnya, dia pun malah mati.\r\nMengapa Pak Toni Sacalu mengundang mereka semua, kemudian mereka harus dibunuh? Siapa sajakah mereka yang tinggal berempat? Siapakah pembunuh sebenarnya, apakah Pak Toni Sacalu atau satu di antara mereka berempat?', 35000, 'playing', '638ee9e37f2b9.png'),
(52, 'F007', 'Orang Kaya Baru', '17:00:00', 'Akibat kemiskinan yang diderita keluarganya, Tika, Duta dan Dodi kerap kali mendapat permasalahan di kampus dan sekolahan. Tika kerap kali menjadi korban bully karena tidak memiliki gadget terkini dan berpenampilan pas-pasan. Sedangkan Duta sendiri mengalami kesulitan dana untuk pertunjukan teater yang akan ia adakan di kampusnya. Sementara si bungsu sendiri selalu dirundung teman-temannya karena keluarganya tidak mampu membelikan sepatu baru untuk menggantikan sepatu Dodi yang sudah bolong-bolong.', 35000, 'playing', '6392d4edd434a.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `informasi_pemesanan`
--

CREATE TABLE `informasi_pemesanan` (
  `kode_pemesanan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_tiket` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `studio`
--

CREATE TABLE `studio` (
  `id_studio` int(11) NOT NULL,
  `no_studio` int(11) NOT NULL,
  `no_seat` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `studio`
--

INSERT INTO `studio` (`id_studio`, `no_studio`, `no_seat`) VALUES
(1, 1, 'A1'),
(2, 1, 'A2'),
(3, 1, 'B1'),
(4, 1, 'B2'),
(5, 1, 'C1'),
(6, 1, 'C2'),
(7, 1, 'D1'),
(8, 1, 'D2'),
(9, 1, 'E1'),
(10, 1, 'E2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tikets`
--

CREATE TABLE `tikets` (
  `id_tiket` int(11) NOT NULL,
  `id_film` int(11) NOT NULL,
  `id_studio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telepon` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `nama`, `no_telepon`, `email`, `username`, `password`) VALUES
(5, 'admin', '000', 'admin', 'admin', 'admin'),
(19, 'wisye', '1234567890', 'Wisyemayaut29@gmail.com', 'aice', '12345678'),
(23, 'Felisia Elvira', '1234567890', 'felisiaelviraa@gmail.com', 'Vira', '12345678');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id_film`);

--
-- Indeks untuk tabel `informasi_pemesanan`
--
ALTER TABLE `informasi_pemesanan`
  ADD PRIMARY KEY (`kode_pemesanan`),
  ADD KEY `informasi_pemesanan_ibfk_1` (`id_user`),
  ADD KEY `informasi_pemesanan_ibfk_2` (`id_tiket`);

--
-- Indeks untuk tabel `studio`
--
ALTER TABLE `studio`
  ADD PRIMARY KEY (`id_studio`);

--
-- Indeks untuk tabel `tikets`
--
ALTER TABLE `tikets`
  ADD PRIMARY KEY (`id_tiket`),
  ADD KEY `tikets_ibfk_1` (`id_film`),
  ADD KEY `tikets_ibfk_2` (`id_studio`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `films`
--
ALTER TABLE `films`
  MODIFY `id_film` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT untuk tabel `informasi_pemesanan`
--
ALTER TABLE `informasi_pemesanan`
  MODIFY `kode_pemesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22213;

--
-- AUTO_INCREMENT untuk tabel `studio`
--
ALTER TABLE `studio`
  MODIFY `id_studio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tikets`
--
ALTER TABLE `tikets`
  MODIFY `id_tiket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `informasi_pemesanan`
--
ALTER TABLE `informasi_pemesanan`
  ADD CONSTRAINT `informasi_pemesanan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `informasi_pemesanan_ibfk_2` FOREIGN KEY (`id_tiket`) REFERENCES `tikets` (`id_tiket`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tikets`
--
ALTER TABLE `tikets`
  ADD CONSTRAINT `tikets_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tikets_ibfk_2` FOREIGN KEY (`id_studio`) REFERENCES `studio` (`id_studio`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
