<?php
session_start();
require "../config/allFunctions.php";


if (!isset($_SESSION["login"])) {
  header('Location: Login.php');
  exit;
}


// var_dump(getAllFilms());

?>

<!DOCTYPE html>
<html>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

  <!-- My CSS -->
  <link rel="stylesheet" href="../resources/style.css" />
  <link rel="shortcut icon" href="../resources/logo.png" />
  <title>Update Film | My Ticket</title>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
          </li>
          <li class="nav-item ml-5">
            <h4 class="nav-link">Selamat Datang, <?php echo $_SESSION['user']; ?>!</h4>
          </li>
        </ul>
      </div>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="MainPage.php">Main Page</a></li>
          <li><a class="dropdown-item" href="TambahFilm.php">Tambah Film</a></li>
          <li><a class="dropdown-item" href="Logout.php">Log Out</a></li>
        </ul>
      </div>
    </div>
  </nav>


  <div class="container mt-5">
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">Kode Film</th>
          <th scope="col">Poster</th>
          <th scope="col">Judul Film</th>
          <!-- <th scope="col">Studio</th> -->
          <th scope="col">Jam Tayang</th>
          <th scope="col">Sinopsis</th>
          <th scope="col">Harga Tiket</th>
          <th scope="col">Status</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $films = getAllFilms();
        foreach ($films as $film) :
        ?>
          <tr>
            <th scope="row"><?php echo $film['kode_film'] ?></th>
            <td><img width="80px" src="../resources/imgFilm/<?php echo $film['poster'] ?>" alt=""></td>
            <td><?php echo $film['judul'] ?></td>
            <!-- <td><?php echo $film['no_seat'] ?></td> -->
            <td><?php echo $film['jam_tayang'] ?></td>
            <td><?php echo $film['sinopsis'] ?></td>
            <td>Rp. <?php echo $film['harga'] ?></td>
            <?php if ($film['status'] === 'playing') : ?>
              <td>Now Playing</td>
            <?php else : ?>
              <td>Coming Soon</td>
            <?php endif; ?>
            <td><a class="btn btn-outline-primary" href="EditFilm.php?id_film=<?php echo $film['id_film'] ?>">Edit</a> | <a onclick="return confirm('Konfirmasi Hapus!')" class="btn btn-outline-danger" href="HapusFilm.php?id_film=<?php echo $film['id_film'] ?>">Hapus</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <br><br>
  <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
    <div class="container text-center">
      <small>Copyright &copy;  My Tickets</small>
    </div>
  </footer>

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
</body>

</html>