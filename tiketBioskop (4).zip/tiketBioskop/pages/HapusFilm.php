<?php 
require '../config/allFunctions.php';

$id = $_GET["id_film"];

if(deleteFilm($id) > 0) {
  header("Location: ListFilm.php");
}
