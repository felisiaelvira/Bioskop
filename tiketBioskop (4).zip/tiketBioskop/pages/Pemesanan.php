 <?php
session_start();
require "../config/allFunctions.php";

if (!isset($_SESSION["login"])) {
  header('Location: Login.php');
  exit;
}

$id = $_GET['kodePesan'];
$pesan = getPemesanan($id)[0];
?>
<!DOCTYPE html>
<html>

<head>
  <title>Cetak Tiket</title>
</head>

<body>
  <div class="box-tiket">
    <div class="kepala-tiket">
      <h1>CINEMA XXI</h1>
      <h2>SLEMAN CITY HALL</h2>
    </div>
    <div class="isi">
      <p>Silahkan datang ke loket Bioskop untuk mengambil & membayar tiket. Di bawah ini adalah Kode Pemesanan Anda,
        jangan sampai Anda melupakannya! </p>
      <h2 style="text-align: center;">Kode Pemesanan : <?php echo $pesan['kode_pemesanan'] ?></h2>
      <h4> <?php echo $pesan['kode_film'] ?> - <?php echo $pesan['judul'] ?></h4>
      <p>Id Tiket : <?php echo $pesan['id_tiket'] ?></p>
      <p>Id User : <?php echo $pesan['id_user'] ?></p>
      <h4>Rp.<?php echo $pesan['total_harga'] ?>,-</h4>
      <p>Silahkan Screen shoot bukti pemesanan tersebut dan cetak bukti pada loket bioskop!</p>
    </div>
    <!-- <button class="btn-print" onclick="b_print()">Print</button> -->
    <a href="MainPage.php" class="btn">Back</a>
  </div>
</body>

</html>
<style type="text/css">
  .btn {
    background-color: #0d6efd;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 0.5rem;
    position: relative;
    top: 1rem;
  }

  .box-tiket {
    position: absolute;
    width: 550px;
    height: 480px;
    color: #4c4447;
    border: 1px dashed #999999;
    font-family: lucida console;
    background-color: #ebf3f4;
  }

  .kepala-tiket {
    width: 100%;
    height: 100px;
    text-align: center;
    font-size: 18px;
    border-bottom: 3px solid #4c4447;
  }

  .kepala-tiket h1 {
    padding: 15px;
    margin: 0;
  }
  .kepala-tiket h2 {
    /* padding: 15px; */
    margin: 0;
  }

  .isi {
    padding: 20px;
    float: left;
  }

  .sesi {
    float: left;
    padding: 0px;
    margin: 0px;
  }

  .sesi h1 {
    font-size: 130px;
  }

  #font {
    font-size: 25px;
    font-weight: bold;
  }

  .btn-print {
    width: 100px;
    padding: 8px 0px;
    border: 1px;
    float: right;
    cursor: pointer;
    background-color: #429cb5;
    color: white;
  }
</style>
<script type="text/javascript">
  function b_print() {
    window.print();
  };
</script>