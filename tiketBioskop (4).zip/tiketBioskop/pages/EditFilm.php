<?php
session_start();
require "../config/allFunctions.php";

if (!isset($_SESSION["login"])) {
  header('Location: Login.php');
  exit;
}

$id = $_GET['id_film'];
$film = getFilmId($id)[0];

if(isset($_POST['submit'])) {
  if(editFilm($_POST, $id) > 0) {
    echo "<script>
            alert('data berhasil diubah')
            document.location.href = 'ListFilm.php';
          </script>";
  } else {
    echo "<script>alert('data gagal diubah')</script>";
  }
}

?>

<style>
  .center {
    margin-left: auto;
    margin-right: auto;
  }
</style>
<!DOCTYPE html>
<html>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

  <!-- My CSS -->
  <link rel="stylesheet" href="../resources/style.css" />
  <link rel="shortcut icon" href="../resources/logo.png" />
  <title>Edit Film | My Ticket</title>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
          </li>
          <li class="nav-item ml-5">
            <h4 class="nav-link">Selamat Datang, <?php echo $_SESSION['user']; ?>!</h4>
          </li>
        </ul>
      </div>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="MainPage.php">Main Page</a></li>
          <li><a class="dropdown-item" href="ListFilm.php">List Film</a></li>
          <li><a class="dropdown-item" href="Logout.php">Log Out</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Akhir Navbar -->
  <br />
  <br />
  <!-- Form Update -->
  <div class="row text-center">
    <div class="col">
      <h2>Edit Film</h2>
    </div>
  </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">

      <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="posterDefault" value="<?php echo $film['poster'] ?>">
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Kode Film</label>
          <input type="text" class="form-control" id="kode" name="kode" maxlength="4" required value="<?php echo $film['kode_film'] ?>">
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Judul</label>
          <input type="text" class="form-control" id="judul" name="judul" required value="<?php echo $film['judul'] ?>">
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Jam Tayang</label>
          <input type="time" class="form-control" id="jam" name="jam" required value="<?php echo $film['jam_tayang'] ?>">
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Sinopsis</label>
          <textarea type="text" class="form-control" id="sinopsis" name="sinopsis" required value=""><?php echo $film['sinopsis'] ?></textarea>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Harga</label>
          <input type="text" class="form-control" id="harga" name="harga" required value="<?php echo $film['harga'] ?>">
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Status</label>
          <select name="status" class="form-select" aria-label="Default select example">
            <?php if ($film['status'] === 'playing') : ?>
              <option selected value="playing">Now Playing</option>
              <option value="soon">Coming Soon</option>
            <?php else : ?>
              <option value="playing">Now Playing</option>
              <option selected value="soon">Coming Soon</option>
            <?php endif; ?>
          </select>
        </div>
        <div class=" mb-3">
          <label for="inputGroupFile02" class="form-label">Poster</label>
          <div class="input-group">
            <input accept="image/*" type="file" class="form-control" id="inputGroupFile02" name="gambar">
            <label class="input-group-text" for="inputGroupFile02" required>Upload</label>
          </div>
        </div>
        <div class="mb-3">
          <img src="../resources/imgFilm/<?php echo $film['poster'] ?>" width="200px" alt="">
          <p class="text-danger">*Gambar Default</p>
        </div>

        <button type="submit" name="submit" class="btn btn-secondary"> Edit Data</button>
      </form>
      <a href="ListFilm.php" class="btn btn-danger">Batal</a>
    </div>
  </div>


  <br><br>
  <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
    <div class="container text-center">
      <small>Copyright &copy;  My Tickets</small>
    </div>
  </footer>

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
</body>

</html>