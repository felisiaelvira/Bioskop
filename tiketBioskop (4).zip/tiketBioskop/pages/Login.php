<?php
session_start();
// include '../config/connection.php';
require '../config/allFunctions.php';
global $conn;

if (isset($_SESSION["login"])) {
    header('Location: MainPage.php');
    exit;
}

if (isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $sql = mysqli_query($conn, "SELECT id_user, username, password FROM users WHERE username = '$username' AND password = '$password'");
    $result = mysqli_num_rows($sql);
    $row = mysqli_fetch_assoc($sql);
    if ($result) {
        $_SESSION["login"] = true;
        $_SESSION['user'] = $row['username'];
        $_SESSION['id'] = $row['id_user'];
        echo "<script>
            alert('Anda berhasil Login!');
            document.location.href = './MainPage.php';
          </script>";
    } else {
        echo "<script>
          alert('Username atau Password Salah');
      </script>";
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- My CSS -->
    <link rel="stylesheet" href="../resources/style.css" />
    <link rel="shortcut icon" href="../resources/logo.png">
    <title>My Ticket</title>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
                    </li>
                </ul>
            </div>
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="Registration.php">Registration</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Akhir Navbar -->
    <br />
    <br />
    <!-- Form Login -->

    <section id="contact">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <h2>Login</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="" method="POST">
                        <div class="mb-2">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" aria-describedby=" username" />
                        </div>
                        <div class="mb-2">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" aria-describedby="password" />
                        </div>
                        <button type="submit" name="submit" class=" btn btn-secondary">Login</button>
                        <br>
                        <div clas="form-footer mt-2">
                            <p>Belum punya account? <a href="Registration.php"> Registration </a></p>
                        </div>



                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Akhir Form Login -->
    <br />
    <br />
    <!-- Footer -->
    <footer id=" sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
        <div class="container text-center">
            <small>Copyright &copy;  My Tickets</small>
        </div>
    </footer>
    <!-- Akhir footer -->
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>