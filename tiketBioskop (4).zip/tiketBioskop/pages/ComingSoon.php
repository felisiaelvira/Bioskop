<?php
session_start();
require '../config/allFunctions.php';


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

  <!-- My CSS -->
  <link rel="stylesheet" href="../resources/style.css" />
  <link rel="shortcut icon" href="../resources/logo.png">
  <title>Coming Soon | My Ticket</title>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
          </li>

          <?php if (isset($_SESSION['login'])) : ?>
            <li class="nav-item ml-5">
              <h4 class="nav-link">Selamat Datang, <?php echo $_SESSION['user']; ?>!</h4>
            </li>
          <?php endif; ?>

        </ul>
      </div>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">

          <?php if (!isset($_SESSION['login'])) : ?>
            <li><a class="dropdown-item" href="Login.php">Login</a></li>
          <?php else : ?>
            <li><a class="dropdown-item" href="MainPage.php">Main Page</a></li>
            <?php if ($_SESSION['user'] === 'admin') : ?>
              <li><a class="dropdown-item" href="TambahFilm.php">Tambah Film</a></li>
              <li><a class="dropdown-item" href="ListFilm.php">List Film</a></li>
            <?php endif; ?>
            <li><a class="dropdown-item" href="Logout.php">Logout</a></li>
          <?php endif; ?>

        </ul>
      </div>
    </div>
  </nav>

  <!-- Akhir Navbar -->
  <br />
  <br />

  <!-- Projects -->
  <section id="projects">
    <div class="container">
      <div class="row text-center">
        <div class="col">
          <h2>COMING SOON</h2>
          <br /><br />
        </div>
      </div>
      <div class="row justify-content-center">

        <?php $films = getAllFilms();
        foreach ($films as $film) :
        ?>
          <?php if ($film['status'] === 'soon') : ?>
            <div class="col-md-3 mb-1">
              <div class="card">
                <img src="../resources/imgFilm/<?php echo $film['poster'] ?>" class="card-img-top" alt="project1" />
                <div class="card-body">
                  <p class="card-text text-center"><?php echo $film['judul'] ?></p>
                  <?php if ($_SESSION['user'] !== 'admin') : ?>
                    <a href="DetailFilm.php?id=<?php echo $film['id_film'] ?>" class="btn btn-primary">SELECT</a>
                  <?php endif; ?>
                  
                </div>
              </div>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <!-- Akir Projects -->

  <br /><br />
  <!-- Projects -->
  <!-- Akir Projects -->
  <br />
  <br />
  <!-- Footer -->
  <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
    <div class="container text-center">
      <small>Copyright &copy; My Tickets</small>
    </div>
  </footer>
  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
</body>

</html>