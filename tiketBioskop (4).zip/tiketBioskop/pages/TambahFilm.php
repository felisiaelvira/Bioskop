<?php
session_start();
require "../config/allFunctions.php";

if (!isset($_SESSION["login"])) {
  header('Location: Login.php');
  exit;
}

if (isset($_POST['submit'])) {
  // var_dump($_POST);
  // var_dump($_FILES);
  // return;
  // if ($_POST['kode'] !== '') {
  // $compare = getKodeFlim($_POST['kode'])[0];
  // if ($_POST['kode'] === $compare['kode_film']) {
  //   echo "<script>
  //           alert('Kode " . $_POST['kode'] . " sudah digunakan')
  //           document.location.href = 'TambahFilm.php'
  //         </script>";
  //   return;
  // }
  // }
  // var_dump(tambahFilm($_POST));die;
  // var_dump($compare);

  //  else {
  // if(tambahFilm($_POST == 0)) {
  //   echo "<script>
  //           alert('data berhasil ditambahkan')
  //           document.location.href = 'TambahFilm.php'
  //         </script>";  
  // } else 

  if (tambahFilm($_POST) > 0) {
    echo "<script>
            alert('data berhasil ditambahkan')
            document.location.href = 'ListFilm.php';
          </script>";
  } else {
    echo "<script>alert('data gagal ditambahkan')</script>";
  }
  // }

}
?>

<style>
  .center {
    margin-left: auto;
    margin-right: auto;
  }
</style>
<!DOCTYPE html>
<html>

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

  <!-- My CSS -->
  <link rel="stylesheet" href="../resources/style.css" />
  <link rel="shortcut icon" href="../resources/logo.png" />
  <title>Tambah Film | My Ticket</title>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
          </li>
          <li class="nav-item ml-5">
            <h4 class="nav-link">Selamat Datang, <?php echo $_SESSION['user']; ?>!</h4>
          </li>
        </ul>
      </div>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <li><a class="dropdown-item" href="MainPage.php">Main Page</a></li>
          <li><a class="dropdown-item" href="ListFilm.php">List Film</a></li>
          <li><a class="dropdown-item" href="Logout.php">Log Out</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Akhir Navbar -->
  <br />
  <br />
  <!-- Form Update -->
  <div class="row text-center">
    <div class="col">
      <h2>Tambah Film</h2>
    </div>
  </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6">

      <form action="" method="post" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Kode Film</label>
          <input type="text" class="form-control" id="kode" name="kode" maxlength="4" required>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Judul</label>
          <input type="text" class="form-control" id="judul" name="judul" required>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Jam Tayang</label>
          <input type="time" class="form-control" id="jam" name="jam" required>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Sinopsis</label>
          <textarea type="text" class="form-control" id="sinopsis" name="sinopsis" required></textarea>
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput2" class="form-label">Harga</label>
          <input type="text" class="form-control" id="harga" name="harga" required>
        </div>
        <div class="mb-3">
        <label for="formGroupExampleInput2" class="form-label">Status</label>
          <select name="status" class="form-select" aria-label="Default select example">
            <option value="playing">Now Playing</option>
            <option value="soon">Coming Soon</option>
          </select>
        </div>
        <div class=" mb-3">
          <label for="inputGroupFile02" class="form-label">Poster</label>
          <div class="input-group">
            <input accept="image/*" type="file" class="form-control" id="inputGroupFile02" name="gambar">
            <label class="input-group-text" for="inputGroupFile02" required>Upload</label>
          </div>
        </div>

        <button type="submit" name="submit" class="btn btn-secondary"> Tambah Data</button>
      </form>
    </div>
  </div>


  <br><br>
  <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
    <div class="container text-center">
      <small>Copyright &copy;  My Tickets</small>
    </div>
  </footer>

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>
</body>

</html>