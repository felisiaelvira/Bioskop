<?php
session_start();
require '../config/allFunctions.php';

if (!isset($_SESSION["login"])) {
  $_SESSION['user'] = null;
  // header('Location: Login.php');
  // exit;
}

$id = $_GET['id'];
// var_dump(getFilmId($id)[0]);
$dataFilm = getFilmId($id)[0];

if (isset($_POST["submit"])) {
  // var_dump($_POST);
  if (buyTiket($_POST, $dataFilm) > 0) {
    $time = time();
    $endTime = substr($time, 6, 4);

    if (addPemesanan($endTime, $_SESSION['id'], $dataFilm['harga']) > 0) {
      echo "<script>alert('Berhasil melakukan pembelian tiket')</script>";
      // $pesan = getPemesanan()[0];
      header("Location: Pemesanan.php?kodePesan=" . $endTime);
    }
  } else {
    echo "<script>alert('Gagal melakukan pembelian tiket')</script>";
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

  <!-- My CSS -->
  <link rel="stylesheet" href="../resources/style.css" />
  <link rel="shortcut icon" href="../resources/logo.png">
  <title>Detail | My Ticket</title>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
          </li>
          <!-- <li class="nav-item ml-5">
            <h4 class="nav-link">Selamat Datang, <?php echo $_SESSION['user']; ?>!</h4>
          </li> -->
        </ul>
      </div>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <?php if ($_SESSION['user'] === 'admin') : ?>
            <li><a class="dropdown-item" href="UpdateFilmAdmin.php">Tambah Film</a></li>
            <li><a class="dropdown-item" href="ListFilm.php">List Film</a></li>
          <?php endif; ?>
          <li><a class="dropdown-item" href="MainPage.php">Main Page</a></li>
          <li><a class="dropdown-item" href="Logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>


  <!-- Projects -->
  <br />
  <br />
  <section id="projects">
    <div class="container">
      <div class="row text-center">
        <div class="col">
          <?php if ($dataFilm['status'] === 'playing') : ?>
            <h2>NOW SHOWING IN CINEMAS</h2>
          <?php else : ?>
            <h2>COMING SOON</h2>
          <?php endif; ?>
          <br /><br />
        </div>
      </div>
      <div class="card mb-5" style="max-width: 1100px;">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="../resources/imgFilm/<?php echo $dataFilm['poster'] ?>" class="img-fluid rounded-start" alt="<?php echo $dataFilm['judul'] ?>">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <?php if ($dataFilm['status'] === 'playing' && $_SESSION['user'] != null) : ?>
                <form action="" method="POST">
                  <h5 class="card-title"><?php echo $dataFilm['judul'] ?></h5><br>
                  <label for="">SLEMAN CITY HALL</label><br><br>
                  <label for="">Harga: Rp.</label>
                  <input type="text" value="<?php echo $dataFilm['harga'] ?>" disabled>
                  <br><br>
                  <label>Jam Tayang:</label>
                  <select name="jam">
                    <option value=""><?php echo $dataFilm['jam_tayang'] ?></option>
                  </select>
                  <label>Seat:</label>
                  <select name="seat">
                    <?php $queryStudio = ("SELECT * FROM studio WHERE id_studio NOT IN (SELECT id_studio 
                                             FROM tikets
                                             WHERE id_film = $id);");
                          $listStudio = mysqli_query($conn, $queryStudio);
                          while ($rowStudio = mysqli_fetch_assoc($listStudio)) : ?>
                      <option value=<?php echo $rowStudio["id_studio"]; ?>><?php echo $rowStudio["no_seat"]; ?></option>
                    <?php endwhile; ?>
                  </select>
                  <br><br>
                  <p class="card-text"><?php echo $dataFilm['sinopsis'] ?></p>

                  <br><br>

                  <?php if ($dataFilm['status'] === 'playing') : ?>
                    <button type="submit" name="submit" class="btn btn-success">Buy Ticket</button>
                  <?php endif; ?>
                </form>
              <?php endif; ?>

              <?php if ($dataFilm['status'] === 'soon' || ($dataFilm['status'] === 'playing' && $_SESSION['user'] == null)) : ?>
                <h5 class="card-title"><?php echo $dataFilm['judul'] ?></h5><br>

                <br><br>
                <p class="card-text">
                  <?php echo $dataFilm['sinopsis'] ?>
                </p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>


    <br />
    <br />
    <!-- Footer -->
    <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
      <div class="container text-center">
        <small>Copyright &copy; My Tickets</small>
      </div>
    </footer>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>