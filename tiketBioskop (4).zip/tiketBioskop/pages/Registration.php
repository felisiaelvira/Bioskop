<?php
// include '../config/connection.php';
require '../config/allFunctions.php';

if (isset($_POST['submit'])) {
    if (register($_POST) > 0) {
        echo "<script>
                alert('Registrasi Berhasil')
                document.location.href = 'Login.php';
            </script>";
    } else if(register($_POST) == -2) {
        echo "<script>
                alert('email telah digunakan')
            </script>";
    } else {
        echo "<script>alert('user gagal ditambahkan')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />

    <!-- My CSS -->
    <link rel="stylesheet" href="../resources/style.css" />
    <link rel="shortcut icon" href="../resources/logo.png">
    <title>My Ticket</title>

    <script type="text/javascript">
        function validasi(form) {
            if (form.password.value.length == 0) {
                alert("Masukkan password Anda");
                return false;
            }
            if (form.password.value.length < 8) {
                alert("password harus sedikitnya 8 karakter");
                return false;
            }
            for (var i = 0; i < form.password.value.length; i++) {
                var ch = form.password.value.charAt(i);
                if ((ch < "A" || ch > "Z") && (ch < "a" || ch > "z") && (ch < "0" || ch > "9")) {
                    alert("password memuat karakter - karakter ilegal");
                    return false;
                }
            }
            // alert("Registrasi Berhasil");

            //return true;
        }
    </script>

</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="../resources/logo.png" alt="" width="100" height="75" class="d-inline-block align-text-top" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="NowPlaying.php">Now Playing</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ComingSoon.php">Coming Soon</a>
                    </li>
                </ul>
            </div>

            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">My-Ticket</button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="Login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
    </nav>

    <!-- Akhir Navbar -->
    <br />
    <br />
    <!-- Form Login -->

    <section id="contact">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <h2>Registration</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="" method="POST" onSubmit="return validasi(this);">
                        <div class=" mb-3">
                            <label for="formGroupExampleInput" class="form-label">Name</label>
                            <input type="text" class="form-control" id="nama" name="nama">
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username">
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class=" mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Handphone</label>
                            <input type="number" class="form-control" id="telepon" name="telepon">
                        </div>
                        <button type="submit" name="submit" class="btn btn-secondary"> Registration</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Akhir Form Login -->
    <br>
    <br>
    <!-- Footer -->
    <footer id="sticky-footer" class="flex-shrink-0 py-5 bg-dark text-white-50">
        <div class="container text-center">
            <small>Copyright &copy;  My Tickets</small>
        </div>
    </footer>
    <!-- Akhir footer -->
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>